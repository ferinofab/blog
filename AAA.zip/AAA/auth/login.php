<?php
session_start();

require '../db.php';
$login = $_POST['login'];
$pass = $_POST['pass'];

$query = $pdo->query("SELECT * FROM users WHERE login='$login' AND password='$pass'")->fetch(PDO::FETCH_ASSOC);
$_SESSION['user_id'] =$query['id'];
$id = $_SESSION['user_id'];

$is_admin = $pdo->query("SELECT * FROM users WHERE $id=36")->fetch(PDO::FETCH_ASSOC);

if($query && !$is_admin){

    $_SESSION['user_id'] = $query['id'];
    header("Location: /AAA/personal/index.php");

}elseif($is_admin){

    $_SESSION['user_id'] = $query['id'];
    header("Location: /AAA/admin/index.php");

} else{
    header("Location: /AAA/reg/login.php");
}

