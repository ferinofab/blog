<?php
session_start();
require $_SERVER['DOCUMENT_ROOT'] . '/AAA/db.php';

$user_id = $_SESSION['user_id'];
$admin_id = 36;


?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <?php if($user_id == $admin_id):?>
        <h1>ссылка на раздел с категориями и статьями</h1>
        <p>список статей</p>
        <a href="articles/index.php">click me</a>
        <p>список категорий</p>
        <a href="categories/index.php">click me</a>

        <a href="/AAA/reg/login.php">выйти</a>
    <?php else:?>
    <?= "пользователь с id: " . $_SESSION['user_id'] . ", ";?>
        <?= "Иди отсюда"?><br>
    <?= "header  у нас не работает, так что выходи сам!"?><br>
        <a href="/AAA/reg/login.php">Вот ссылка на выход</a>
    <?php endif;?>

</body>
</html>