<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<form action="/AAA/auth/login.php" method="post">
    <input type="text" placeholder="login" name="login">
    <input type="password" placeholder="pass"  name="pass">
    <input type="submit">
</form>
<a href="register.php">register</a>
</body>
</html>