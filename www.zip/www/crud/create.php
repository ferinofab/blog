<?php
require $_SERVER['DOCUMENT_ROOT'].'/db.php';
$categories = $pdo ->query("SELECT * FROM category")->fetchAll(PDO::FETCH_ASSOC);

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<h1>Создать вакансию</h1>
<form action="auth/store.php" method="post">
    <input type="text" placeholder="название" name="name">
    <input type="text" placeholder="slug" name="slug">
    <input type="text" placeholder="цена" name="price">
    <input type="text" placeholder="тип занятости" name="type_of_employment">
    <input type="text" placeholder="опыт работы" name="experience">
    <input type="text" placeholder="уровень квалификации" name="skill_level">
    <input type="text" placeholder="описание" name="description">
    <select name="select" id="">
        <option value=""></option>
        <?php foreach ($categories as $category):?>
            <option value="$category['id']"><?=$category['name']?></option>
        <?php endforeach;?>
    </select>
    <input type="submit">
</form>
</body>
</html>
