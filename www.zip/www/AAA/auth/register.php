<?php
session_start();
$pdo = require $_SERVER['DOCUMENT_ROOT'] . '/db.php';
$login = $_POST["login"];
$pass = $_POST["password"];


$_SESSION['pass'] = $pass;


$query = $pdo->prepare("INSERT INTO users (login, password) VALUES (?, ?)")->execute([
    $login,
    $pass
]);

$a = $pdo->query("SELECT id FROM users WHERE login='$login' AND password='$pass'")->fetch(PDO::FETCH_ASSOC);
$_SESSION['user_id'] = $a['id'];
$id = $a['id'];

header("Location: /AAA/personal_a/index.php");

//$query = $pdo->prepare("INSERT INTO users (login, password) VALUES (:login, :pass)")->execute([
//    'login' =>$login,
//    'pass'=>$pass
//]);