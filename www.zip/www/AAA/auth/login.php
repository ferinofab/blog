<?php
$pdo = require $_SERVER['DOCUMENT_ROOT'] . '/db.php';

session_start();
$login = $_POST['login'];
$pass = $_POST['pass'];



$userQury = $pdo ->prepare("SELECT * FROM users WHERE login = ?");

$userQury->execute([$login] );

$user = $userQury->fetch(PDO::FETCH_ASSOC);

if(!$user || $user['password'] != $pass){
    header('Location: /reg/register.php');
    exit();
}



$_SESSION['user_id'] = $user['id'];
echo $_SESSION['user_id'];

header("Location: http://localhost/AAA/personal_a/index.php");