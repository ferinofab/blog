<?php
require $_SERVER['DOCUMENT_ROOT'] . '/AAA/db.php';
$id = $_GET['id'];
$pdo->query("DELETE FROM categories WHERE id='$id'");
header("Location: /admin/categories/");
