<?php
require $_SERVER['DOCUMENT_ROOT'] . '/AAA/db.php';

$name_cat = $_POST['name_cat'];
$pdo->query("INSERT INTO categories (name) VALUES ('$name_cat')");
header("Location: /admin/categories/");
