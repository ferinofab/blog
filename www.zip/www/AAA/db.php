<?php
//
//$pdo = new PDO('mysql:host=MySQL-8.2;dbname=docker;', 'root', '');
//return $pdo;

$pdo = new PDO('mysql:host=database;dbname=docker', 'root', 'tiger');
return $pdo;