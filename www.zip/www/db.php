<?php
$pdo = new PDO('mysql:host=database;dbname=job', 'root', 'tiger');
return $pdo;