<?php

    $data = 'mysql:host=database;dbname=docker';
    return new PDO('mysql:host=database;dbname=docker', 'root', 'tiger');