<?php
session_start();
require $_SERVER['DOCUMENT_ROOT'] . '/db.php';

$eamil = $_POST['email'];
$pass = $_POST['pass'];
$select = $pdo -> query("SELECT * FROM users WHERE email = '$eamil' AND pass = '$pass'")->fetch(PDO::FETCH_ASSOC);
if($select){
    $_SESSION['user_id'] = $select['id'];
}
if($select){
    header("Location: /index.php");
}else{
    header("Location: /reg/login.php");
}

