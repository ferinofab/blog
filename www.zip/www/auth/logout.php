<?php
session_start();
session_destroy();
header('Location: /reg/login.php');