<?php
require $_SERVER['DOCUMENT_ROOT'] . '/db.php';
$name = $_POST['name'];
$slug = $_POST['slug'];
$price = $_POST['price'];
$type_of_employment = $_POST['type_of_employment'];
$experience = $_POST['experience'];
$skill_level = $_POST['skill_level'];
$description = $_POST['description'];
$select = $_POST['select'];
$pdo->query("INSERT INTO vacancy (name, slug, price, type_of_employment, experience, skill_level, description) VALUES ('$name', '$slug', $price, $type_of_employment, $experience, $skill_level, $description)");
