<?php
/** @var PDO $pdo */
$pdo = require $_SERVER['DOCUMENT_ROOT'] . '/Blog/db.php';
$name_articles = $pdo->query("SELECT name FROM articles")->fetchAll(PDO::FETCH_ASSOC);

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<h1>Редактирование статьи</h1>
<table>
    <thead>
    <tr>
        <td>Название статьи</td>
        <td>Выбор модерации</td>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($name_articles as $iteam): ?>
        <tr>
            <td>

                <p><?= $iteam['name'] ?></p>

            </td>
            <td>
                <select name="mod">
                    <option value="<?= null?>"></option>
                    <option value="<?=true?>>">Модерировать</option>
                    <option value="<?=false?>>">Не модерировать</option>
                </select>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<button>
    <a href="actions/update.php">Применить</a>
</button>
</body>
</html>