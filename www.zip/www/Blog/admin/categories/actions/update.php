<?php
$pdo = require $_SERVER['DOCUMENT_ROOT'].'/Blog/db.php';

$id = $_POST['id'];
$name = $_POST['name'];

$pdo->query("UPDATE `categories` SET `name` = '$name' WHERE `id` = '$id'");
header('Location: /Blog/admin/categories/index.php');