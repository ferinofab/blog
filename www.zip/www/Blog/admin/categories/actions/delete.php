<?php
$pdo = require $_SERVER['DOCUMENT_ROOT'].'/Blog/db.php';
$id = $_GET['id'];

$pdo->query("DELETE FROM categories WHERE id = '$id'");
header("Location: /Blog/admin/categories/index.php");