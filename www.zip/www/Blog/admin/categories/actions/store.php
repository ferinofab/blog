<?php
$pdo = require $_SERVER['DOCUMENT_ROOT'].'/Blog/db.php';
$name = $_POST['name'];

$pdo->query("INSERT INTO `categories` (name) VALUES ('$name')");
header('Location: /Blog/admin/categories/index.php');