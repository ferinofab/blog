<?php
$pdo = require $_SERVER['DOCUMENT_ROOT'].'/Blog/db.php';
$id = $_GET['id'];

$category = $pdo->query("SELECT * FROM categories WHERE id = '$id'");

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="actions/update.php" method="post">
        <?php foreach ($category as $item):?>
            <input type="hidden" name="id" value="<?= $item['id']?>">
            <input type="text" name="name" value="<?= $item['name']?>">
        <?php endforeach;?>
        <input type="submit">
    </form>
</body>
</html>