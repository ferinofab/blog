<?php
/** @var PDO $pdo */
$pdo = require $_SERVER['DOCUMENT_ROOT']. '/Blog/db.php';
$categories = $pdo->query("SELECT * FROM categories")->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="`en`">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<a href="create.php">Добавление категории</a>
    <table>
        <thaed>
            <tr>
                <td>#</td>
                <td>name</td>
            </tr>
        </thaed>
        <tbody>
        <?php foreach ($categories as $category) : ?>
            <tr>
                <td><?= $category['id']?></td>
                <td><?= $category['name']?></td>
                <td><a href="edit.php?id=<?=$category['id']?>">Редактировать</a></td>
                <td><a href="actions/delete.php?id=<?=$category['id']?>">Удалить</a></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>